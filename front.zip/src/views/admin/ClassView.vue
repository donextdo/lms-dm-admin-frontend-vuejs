<template>
  <div class="classes-page">
   <router-view>
    
   </router-view>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
  .classes-page {
    width: 100%;
    z-index: -9999;
    overflow: hidden;
  }
</style>