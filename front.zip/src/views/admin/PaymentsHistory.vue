<template>
    <div class="Due">
      <header class="header">
        <div class="th">
          <div class="td">
            <span>Student</span>
            <svg width="10" height="20" viewBox="0 0 10 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8.50765 8H1.49235C1.21539 8.00043 0.943985 7.9164 0.70954 7.75763C0.475096 7.59886 0.287202 7.37185 0.167607 7.10287C0.0276073 6.78372 -0.0263148 6.42864 0.0119851 6.0781C0.0502851 5.72756 0.179267 5.39565 0.384232 5.12021L3.89188 0.544835C4.02954 0.373815 4.19972 0.236656 4.39091 0.142653C4.5821 0.04865 4.78982 0 5 0C5.21018 0 5.4179 0.04865 5.60909 0.142653C5.80028 0.236656 5.97046 0.373815 6.10812 0.544835L9.61577 5.12021C9.82073 5.39565 9.94972 5.72756 9.98802 6.0781C10.0263 6.42864 9.97239 6.78372 9.83239 7.10287C9.7128 7.37185 9.5249 7.59886 9.29046 7.75763C9.05602 7.9164 8.78461 8.00043 8.50765 8Z" fill="black"/>
            <path d="M1.49235 12H8.50765C8.78461 11.9996 9.05602 12.0836 9.29046 12.2424C9.5249 12.4011 9.7128 12.6282 9.83239 12.8971C9.97239 13.2163 10.0263 13.5714 9.98801 13.9219C9.94971 14.2724 9.82073 14.6043 9.61577 14.8798L6.10812 19.4552C5.97046 19.6262 5.80028 19.7633 5.60909 19.8573C5.4179 19.9514 5.21018 20 5 20C4.78982 20 4.5821 19.9514 4.39091 19.8573C4.19972 19.7633 4.02954 19.6262 3.89188 19.4552L0.384231 14.8798C0.179266 14.6043 0.0502844 14.2724 0.0119839 13.9219C-0.0263157 13.5714 0.0276079 13.2163 0.167608 12.8971C0.287203 12.6282 0.475097 12.4011 0.70954 12.2424C0.943985 12.0836 1.21539 11.9996 1.49235 12Z" fill="black"/>
            </svg>
          </div>
        </div>
  
        <div class="th">
          <div class="td">
            <span>Payment Date</span>
            <svg width="10" height="20" viewBox="0 0 10 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8.50765 8H1.49235C1.21539 8.00043 0.943985 7.9164 0.70954 7.75763C0.475096 7.59886 0.287202 7.37185 0.167607 7.10287C0.0276073 6.78372 -0.0263148 6.42864 0.0119851 6.0781C0.0502851 5.72756 0.179267 5.39565 0.384232 5.12021L3.89188 0.544835C4.02954 0.373815 4.19972 0.236656 4.39091 0.142653C4.5821 0.04865 4.78982 0 5 0C5.21018 0 5.4179 0.04865 5.60909 0.142653C5.80028 0.236656 5.97046 0.373815 6.10812 0.544835L9.61577 5.12021C9.82073 5.39565 9.94972 5.72756 9.98802 6.0781C10.0263 6.42864 9.97239 6.78372 9.83239 7.10287C9.7128 7.37185 9.5249 7.59886 9.29046 7.75763C9.05602 7.9164 8.78461 8.00043 8.50765 8Z" fill="black"/>
            <path d="M1.49235 12H8.50765C8.78461 11.9996 9.05602 12.0836 9.29046 12.2424C9.5249 12.4011 9.7128 12.6282 9.83239 12.8971C9.97239 13.2163 10.0263 13.5714 9.98801 13.9219C9.94971 14.2724 9.82073 14.6043 9.61577 14.8798L6.10812 19.4552C5.97046 19.6262 5.80028 19.7633 5.60909 19.8573C5.4179 19.9514 5.21018 20 5 20C4.78982 20 4.5821 19.9514 4.39091 19.8573C4.19972 19.7633 4.02954 19.6262 3.89188 19.4552L0.384231 14.8798C0.179266 14.6043 0.0502844 14.2724 0.0119839 13.9219C-0.0263157 13.5714 0.0276079 13.2163 0.167608 12.8971C0.287203 12.6282 0.475097 12.4011 0.70954 12.2424C0.943985 12.0836 1.21539 11.9996 1.49235 12Z" fill="black"/>
            </svg>
          </div>
        </div>
  
        <div class="th">
          <div class="td">
            <span>Grade</span>
            <svg width="10" height="20" viewBox="0 0 10 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M8.50765 8H1.49235C1.21539 8.00043 0.943985 7.9164 0.70954 7.75763C0.475096 7.59886 0.287202 7.37185 0.167607 7.10287C0.0276073 6.78372 -0.0263148 6.42864 0.0119851 6.0781C0.0502851 5.72756 0.179267 5.39565 0.384232 5.12021L3.89188 0.544835C4.02954 0.373815 4.19972 0.236656 4.39091 0.142653C4.5821 0.04865 4.78982 0 5 0C5.21018 0 5.4179 0.04865 5.60909 0.142653C5.80028 0.236656 5.97046 0.373815 6.10812 0.544835L9.61577 5.12021C9.82073 5.39565 9.94972 5.72756 9.98802 6.0781C10.0263 6.42864 9.97239 6.78372 9.83239 7.10287C9.7128 7.37185 9.5249 7.59886 9.29046 7.75763C9.05602 7.9164 8.78461 8.00043 8.50765 8Z" fill="black"/>
            <path d="M1.49235 12H8.50765C8.78461 11.9996 9.05602 12.0836 9.29046 12.2424C9.5249 12.4011 9.7128 12.6282 9.83239 12.8971C9.97239 13.2163 10.0263 13.5714 9.98801 13.9219C9.94971 14.2724 9.82073 14.6043 9.61577 14.8798L6.10812 19.4552C5.97046 19.6262 5.80028 19.7633 5.60909 19.8573C5.4179 19.9514 5.21018 20 5 20C4.78982 20 4.5821 19.9514 4.39091 19.8573C4.19972 19.7633 4.02954 19.6262 3.89188 19.4552L0.384231 14.8798C0.179266 14.6043 0.0502844 14.2724 0.0119839 13.9219C-0.0263157 13.5714 0.0276079 13.2163 0.167608 12.8971C0.287203 12.6282 0.475097 12.4011 0.70954 12.2424C0.943985 12.0836 1.21539 11.9996 1.49235 12Z" fill="black"/>
            </svg>
          </div>
        </div>
        <div class="th">
          <div class="td">
           <div style="top:20px; height:40px;display:grid;grid-template-columns:90% 12%; border-radius:50px;width:max-content;background-color: white; ">
            <v-text-field    loading="false"
               style="padding-left:160px;margin:0;top:-10px; position: relative ;border-radius:50px;" >
            </v-text-field>
            <button style="margin-top:4px;">
            <svg width="32"  height="32" viewBox="0 0 39 39" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="19.5" cy="19.5" r="19.5" fill="#FFA500"/>
            </svg>  
                        <svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg" style="top:-30px; left:0px; position:relative;">
            <path d="M8 0C3.589 0 0 3.589 0 8C0 12.411 3.589 16 8 16C9.77498 15.9996 11.4988 15.4054 12.897 14.312L17.293 18.708L18.707 17.294L14.311 12.898C15.405 11.4997 15.9996 9.77544 16 8C16 3.589 12.411 0 8 0Z" fill="white"/>
            </svg>
        </button>
          </div> 
          </div>  
        </div>
      </header>
      <section class="hero d-flex flex-column">
       <PaymentsHistoryRowVue></PaymentsHistoryRowVue>

      </section>
      <PaymentDetailsVue v-if="false"></PaymentDetailsVue>
    </div>
  </template>
  
  <script>
  import PaymentsHistoryRowVue from './PaymentsHistoryRow.vue';
  import PaymentDetailsVue from './PaymentDetails.vue';
  export default {
      name: 'Due-vue',
  
      components: {
       PaymentsHistoryRowVue,
       PaymentDetailsVue
      },
  
    }
      
  
  
  </script>
  
  <style scoped>
  
    .Due {
      width: 100%;
      padding-left: 50px;
      padding-right: 70px;
      position: relative;
    }
  

    .header {
      padding: 0 0px 0 0px;
      width: 100%;
      height: 75px;
      display: grid;
      grid-template-columns:20% 20% 20% 40%;
    }
  
    .th {
      width: 100%;
      height: 100%;
      position: relative;
    }
  
    .td {
        width:100%;
      position: absolute;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 13px;
      bottom: 25px;
      left: 0;
      
    }
  
  
    .td > span {
      font-size: 16px;
      font-weight: 700;
      line-height: 32px;
      opacity: 0.5;
    }
  
    .td > svg {
      height: 16px;
    }
  
    .btn {
      font-size: 18px;
      text-transform: capitalize;
      font-weight: bold;
      position: absolute;
      bottom: 25px;
      right: 0;
    }
  
    .hero {
      overflow-y: scroll;
      height: 800px;
      gap: 35px;
    }
  
    ::-webkit-scrollbar {
      width: 8px;
    }
  
    ::-webkit-scrollbar-track {
      background: transparent;
    }
  
    ::-webkit-scrollbar-thumb {
      background: rgba(255, 165, 0, 0.4);
      border-radius: 5px;
    }
  
    ::-webkit-scrollbar-thumb:hover {
      background: rgba(255, 165, 0, 0.6);
    }
  
    .card-enter-active,
    .card-leave-active {
      transition: opacity 0.3s ease-in;
    }
  
    .card-enter-from {
      opacity: 0;
    }
  
    .card-enter-to {
      opacity: 1;
    }
  
    .card-leave-to {
      opacity: 0;
    }
  
    @media (max-width: 1400px) {
      .tutors {
        padding-inline: 100px;
      }
  
      .alert {
        top: -2rem;
        right: 2rem;
      }
  
      .header {
        padding: 0 8px 0 20px;
        height: 100px;
        /* grid-template-columns: 3fr 2fr 1.2fr 3fr; */
      }
  
      .td {
        gap: 8px;
        bottom: 12px;
      }
  
      .td > span {
        font-size: 12px;
      }
  
      .td > svg {
        height: 12px;
      }
  
      .btn {
        font-size: 12px;
        bottom: 12px;
      }
  
      .hero {
        height: 500px;
        gap: 25px;
      }
    }
  </style>